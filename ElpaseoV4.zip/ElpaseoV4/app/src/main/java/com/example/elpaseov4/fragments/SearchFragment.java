package com.example.elpaseov4.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.elpaseov4.R;
import com.example.elpaseov4.activities.DetailProductActivity;
import com.example.elpaseov4.adapters.CategoryAdapter;
import com.example.elpaseov4.adapters.ProductAdapter;
import com.example.elpaseov4.model.Category;
import com.example.elpaseov4.model.Product;
import com.example.elpaseov4.network.Pagination;
import com.example.elpaseov4.network.RetrofitClientInstance;
import com.example.elpaseov4.network.ServiceRetrofit;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SearchFragment extends Fragment {

    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView mRecyclerViewCategories;
    private RecyclerView.LayoutManager mLayoutManagerCategories;
    private ServiceRetrofit service;
    private Long categoryIdToSearch;

    String properties = "[{\"key\": \"categories.id\", \"value\": 3}]";
    String range = "1,20";
    String fieldsTosort = "id,desc";
    public SearchFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        return view;
    }
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        service = RetrofitClientInstance.getRetrofitInstance().create(ServiceRetrofit.class);

        cargarCategories(service,view );


        mRecyclerView = this.getView().findViewById(R.id.recyclerView);

        mLayoutManager = new LinearLayoutManager(this.getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        ////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////
        service.getProducts().enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                System.out.println(response.code());
                mAdapter = new ProductAdapter(response.body(), R.layout.recycler_view_item_product_list, new ProductAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(final Product p, int position) {

                    }
                });
                mRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                /*mAdapter = new ProductAdapter(getAllProducts(), R.layout.recycler_view_item_product_list, new ProductAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(final Product name, int position) {
                        Toast.makeText(view.getContext(), "miProducto" + name,Toast.LENGTH_LONG).show();
                    }
                });*/
                System.out.println("Falla");
                System.out.println(t.getMessage());
                //mRecyclerView.setAdapter(mAdapter);
            }
        });
        ////////////////////////////////////////////////////////////////

        /*service.getProducts(range,fieldsTosort,properties).enqueue(new Callback<Pagination>() {
            @Override
            public void onResponse(Call<Pagination> call, Response<Pagination> response) {
                mAdapter = new ProductAdapter(response.body().getPage(), R.layout.recycler_view_item_product_list, new ProductAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(final Product p, int position) {

                    }
                });
                mRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(Call<Pagination> call, Throwable t) {
                System.out.println(t.getMessage());
            }
        });*/

    }



    public void cargarCategories(ServiceRetrofit service, View view){

        mRecyclerViewCategories = this.getView().findViewById(R.id.recyclerViewCategories);

        mLayoutManagerCategories = new LinearLayoutManager(this.getActivity(),RecyclerView.HORIZONTAL,false);
        mRecyclerViewCategories.setLayoutManager(mLayoutManagerCategories);
        mRecyclerViewCategories.setItemAnimator(new DefaultItemAnimator());

        service.getCategories().enqueue(new Callback<List<Category>>() {
            @Override
            public void onResponse(Call<List<Category>> call, Response<List<Category>> response) {
                Toast.makeText(view.getContext(), "Traje las categorias" ,Toast.LENGTH_LONG).show();
                System.out.println(response.code());
                mAdapter = new CategoryAdapter(response.body(), R.layout.recycler_view_item_category_list_horizontal, new CategoryAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(final Category name, int position) {
                        Toast.makeText(view.getContext(), "miProducto" + name,Toast.LENGTH_LONG).show();
                    }
                });
                mRecyclerViewCategories.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(Call<List<Category>> call, Throwable t) {

            }
        });


    }
}