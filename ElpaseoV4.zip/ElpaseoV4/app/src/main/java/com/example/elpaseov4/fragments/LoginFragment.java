package com.example.elpaseov4.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.elpaseov4.R;
import com.example.elpaseov4.model.User;
import com.example.elpaseov4.network.LoginUser;
import com.example.elpaseov4.network.RetrofitClientInstance;
import com.example.elpaseov4.network.ServiceRetrofit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class LoginFragment extends Fragment {
    EditText email;
    EditText encryptedPassword;
    Button buttonLogin;
    private ServiceRetrofit service;

    public LoginFragment() {
        // Required empty public constructor

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        email = view.findViewById(R.id.editTextUser);
        encryptedPassword = view.findViewById(R.id.editTextPassword);
        buttonLogin = view.findViewById(R.id.buttonLogin);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "Logueando", Toast.LENGTH_LONG).show();
                String name = email.getText().toString();
                String password = encryptedPassword.getText().toString();

                LoginUser loginUser = new LoginUser(name,password);

                service = RetrofitClientInstance.getRetrofitInstance().create(ServiceRetrofit.class);

                service.login(loginUser).enqueue(new Callback<User>() {
                    @Override
                    public void onResponse(Call<User> call, Response<User> response) {

                        if (response.isSuccessful()){
                            response.body();
                            Toast.makeText(v.getContext(), "EXITO2222", Toast.LENGTH_LONG).show();
                            guardarPreferencias(response.body().getValue());

                            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            fragmentTransaction.replace(R.id.container,new MainHomeFragment());
                            fragmentTransaction.commit();
                        }else {
                            Toast.makeText(v.getContext(), "Datos erroneos", Toast.LENGTH_LONG).show();
                            Fragment loginFragment = new LoginFragment();

                            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            fragmentTransaction.replace(R.id.container,loginFragment);
                            fragmentTransaction.commit();
                        }
                    }


                    @Override
                    public void onFailure(Call<User> call, Throwable t) {
                        System.out.println(t.getMessage());
                        Toast.makeText(v.getContext(), "Fracaso", Toast.LENGTH_LONG).show();
                        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.container,new MainHomeFragment());
                        fragmentTransaction.commit();
                    }
                });

            }
        });
        return view;
    }

    public void guardarPreferencias(String n){
        SharedPreferences preferences = getActivity().getSharedPreferences("credenciales", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("value",n);
        editor.commit();

    }


}