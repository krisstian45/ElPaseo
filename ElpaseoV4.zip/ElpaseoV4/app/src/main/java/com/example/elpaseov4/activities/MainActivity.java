package com.example.elpaseov4.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.elpaseov4.R;
import com.example.elpaseov4.fragments.CartFragment;
import com.example.elpaseov4.fragments.LoginFragment;
import com.example.elpaseov4.fragments.MainHomeFragment;
import com.example.elpaseov4.fragments.OrderDetailFragment;
import com.example.elpaseov4.fragments.OrdersFragment;
import com.example.elpaseov4.fragments.RegisterFragment;
import com.example.elpaseov4.fragments.SearchFragment;
import com.example.elpaseov4.model.User;
import com.example.elpaseov4.network.ServiceRetrofit;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    Toolbar toolbar;
    NavigationView navigationView;
    TextView textView;
    private static MainActivity activityMain;
    //Cargar usuario
    User user;

    private ServiceRetrofit service;

    //variables para cargar fragment
    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        activityMain=this;


        toolbar = findViewById(R.id.toolbarDrawer);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.navigationView);
        ///
        SharedPreferences preferences = getSharedPreferences("credenciales", Context.MODE_PRIVATE);
        String mail = preferences.getString("value","No existe la informacion");
        if (mail == "No existe la informacion" ){
            System.out.println("entre al if");
            navigationView.getMenu().setGroupVisible(R.id.groupUserLogin,false);
        }else {
            System.out.println("entre al else");
            navigationView.getMenu().setGroupVisible(R.id.groupUserLogin,true);

            /*navigationView.findViewById(R.id.user_login_in).setVisibility(View.GONE);
            TextView textView=navigationView.findViewById(R.id.user_name);
            textView.setText(mail);
            navigationView.findViewById(R.id.user_name).setVisibility(View.VISIBLE);*/
        }
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open,R.string.close);
        //cambiar icono
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        //establecer evento onclick al navigationview
        navigationView.setNavigationItemSelectedListener(this);

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        actionBarDrawerToggle.syncState();


        //cargar Fragment principal
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.container,new MainHomeFragment());
        fragmentTransaction.commit();

    }

    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        drawerLayout.closeDrawer(GravityCompat.START);

        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        switch (item.getItemId() ){
            case R.id.home:
                fragmentTransaction.replace(R.id.container,new MainHomeFragment());
                fragmentTransaction.commit();
                break;
            case R.id.busqueda:
                fragmentTransaction.replace(R.id.container,new SearchFragment());
                fragmentTransaction.commit();
                break;
            case R.id.carrito:
                fragmentTransaction.replace(R.id.container,new CartFragment());
                fragmentTransaction.commit();
                break;
            case R.id.pedidos:
                fragmentTransaction.replace(R.id.container,new OrdersFragment());
                fragmentTransaction.commit();
                break;
            case R.id.logOut:
                btnLogOut();
                break;
        }
        return false;
    }

    public static MainActivity getmInstanceActivityMain(){
        return activityMain;
    }

    public void login(View view){
        Toast.makeText(getApplicationContext(), "Me voy a loguear", Toast.LENGTH_LONG).show();
        drawerLayout.closeDrawer(GravityCompat.START);
        Fragment loginFragment = new LoginFragment();

        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container,loginFragment);
        fragmentTransaction.commit();
    }

    public void btnLogOut(){
        Toast.makeText(getApplicationContext(), "Cerrar Sesion", Toast.LENGTH_LONG).show();
        SharedPreferences preferences = getSharedPreferences("credenciales", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("value","No existe la informacion");
        editor.commit();

        drawerLayout.closeDrawer(GravityCompat.START);
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container,new MainHomeFragment());
        fragmentTransaction.commit();
    }

    public void register(View view){
        Toast.makeText(getApplicationContext(), "Me voy a Registrar", Toast.LENGTH_LONG).show();
        drawerLayout.closeDrawer(GravityCompat.START);

        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container,new RegisterFragment());
        fragmentTransaction.commit();
    }
    public void cancelRegister(View view){
        Toast.makeText(getApplicationContext(), "Cancelo", Toast.LENGTH_LONG).show();
        drawerLayout.closeDrawer(GravityCompat.START);

        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container,new MainHomeFragment());
        fragmentTransaction.commit();
    }
    public void payCart(View view){
        Toast.makeText(getApplicationContext(), "Ya pago", Toast.LENGTH_LONG).show();
        drawerLayout.closeDrawer(GravityCompat.START);

        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container,new OrderDetailFragment());
        fragmentTransaction.commit();
    }

}