package com.example.elpaseov4.fragments;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.elpaseov4.R;
import com.example.elpaseov4.model.Category;
import com.example.elpaseov4.model.Imagen;
import com.example.elpaseov4.model.Product;

import java.util.List;

import retrofit2.http.POST;


public class DetailProductFragment extends Fragment {
    ImageView imageViewDetail;
    TextView textViewDetail;
    TextView textViewDescripcion;
    private Product productDetail;
    public DetailProductFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_detail_product, container, false);

        Bundle bundle = this.getArguments();
        if (bundle != null) {
            Category productDetail = (Category)bundle.getSerializable("producto");
        }

        return view;
    }


    private static Bitmap obtenerImagen(Product p) {
        List<Imagen> temp = p.getImages();
        Imagen local =null ;
        for (Imagen image: temp ) {
            if (image.getIsMain() != null) {
                if (image.getIsMain() == "true" ){
                    local = image;
                }
            }
        }

        String base64String = local.getValue();
        String base64Image = base64String.split(",")[1];

        byte[] decodedString = Base64.decode(base64Image, Base64.DEFAULT);

        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
    }
}